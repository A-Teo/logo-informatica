<?php
session_start();
error_reporting(E_ALL);

?>
