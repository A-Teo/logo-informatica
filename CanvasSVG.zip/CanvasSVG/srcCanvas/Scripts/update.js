var actualizarElementos = {
    rotarTexto1: function() {
    	textoRotatorio1.rotation.x += 0.02;
    },
    rotarTexto2: function() {
        textoRotatorio2.rotation.y += 0.02;
    },
    rotarNubes: function () {
        nubesRotatorias.rotation.y += 0.001;
    }
}